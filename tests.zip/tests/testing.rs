use crate::graph::{read_file, adjacency_list, test_read_file, test_adjacency_list};

#[test]
fn test_read_file() {
// Replace with the path to a test file
let file_path = "soc-redditHyperlinks-body.tsv";

// Call the function you want to test
let result = read_file(file_path);
        
// Perform assertions to check if the function behaved as expected
assert!(result.is_some(), "Failed to read file");
// Add more assertions as needed
}

#[test]
fn test_adjacency_list() {
// Replace with the path to a test file
let file_path = "soc-redditHyperlinks-body.tsv";

// Call the function you want to test
let result = read_file(file_path);
assert!(result.is_some(), "Failed to read file");

let adjacency_list_result = adjacency_list(&result.unwrap());
        
// Perform assertions to check if the function behaved as expected
assert_eq!(adjacency_list_result.len(), 10, "Actual length: {}", adjacency_list_result.len());
}

